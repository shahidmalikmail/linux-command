## Reporting a Vulnerability

If you discover a potential security issue in this project please notify me via email to anton@antonbabenko.com.
 
Please do **not** create a public github issue.
