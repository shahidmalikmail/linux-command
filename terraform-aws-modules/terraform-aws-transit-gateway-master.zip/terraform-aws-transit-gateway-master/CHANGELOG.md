<a name="unreleased"></a>
## [Unreleased]



<a name="v1.1.0"></a>
## [v1.1.0] - 2020-01-16

- Updated notes in example


<a name="v1.0.0"></a>
## [v1.0.0] - 2020-01-15

- Updated CHANGELOG
- Added code for the module


<a name="v0.0.1"></a>
## v0.0.1 - 2020-01-15

- Initial commit


[Unreleased]: https://github.com/terraform-aws-modules/terraform-aws-transit-gateway/compare/v1.1.0...HEAD
[v1.1.0]: https://github.com/terraform-aws-modules/terraform-aws-transit-gateway/compare/v1.0.0...v1.1.0
[v1.0.0]: https://github.com/terraform-aws-modules/terraform-aws-transit-gateway/compare/v0.0.1...v1.0.0
