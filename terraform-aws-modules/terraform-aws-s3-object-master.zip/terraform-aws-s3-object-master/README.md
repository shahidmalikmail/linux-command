# terraform-aws-s3-object
Terraform module which creates S3 object resources on AWS
