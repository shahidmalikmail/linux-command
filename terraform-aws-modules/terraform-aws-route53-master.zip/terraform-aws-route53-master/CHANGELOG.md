# Change Log

All notable changes to this project will be documented in this file.

<a name="unreleased"></a>
## [Unreleased]



<a name="v0.1.0"></a>
## v0.1.0 - 2020-06-17

- Added route53 modules for zones and records


[Unreleased]: https://github.com/terraform-aws-modules/terraform-aws-route53/compare/v0.1.0...HEAD
