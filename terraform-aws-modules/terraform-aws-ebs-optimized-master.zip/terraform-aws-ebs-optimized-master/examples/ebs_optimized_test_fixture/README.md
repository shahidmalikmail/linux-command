# eks_test_fixture example

This set of templates serves a few purposes. It:

1.  shows developers how to use the module in a straightforward way as integrated with other terraform community supported modules.
2.  serves as the test infrastructure for CI on the project.
